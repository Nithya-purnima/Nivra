import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

export default function ProductList() {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await api.get("/products");
        setProducts(res.data);
      } catch (err) {
        console.error("Error fetching products:", err);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Available Products</h2>

      <div className="row">
        {products.map((p) => (
          <div className="col-md-4 mb-3" key={p.id}>
            <div
              className="card h-100"
              onClick={() => navigate(`/products/${p.id}`)}
              style={{ cursor: "pointer" }}
            >
              {/* ✅ IMAGE FIX */}
              <img
                src={
                  p.image
                    ? `http://localhost:8080/api/products/image/${p.image}`
                    : "https://via.placeholder.com/300x200"
                }
                className="card-img-top"
                alt={p.name}
                style={{ height: "200px", objectFit: "cover" }}
              />

              <div className="card-body d-flex flex-column">
                {/* ✅ FIELD FIX */}
                <h5 className="card-title">{p.name}</h5>
                <p className="card-text">{p.description}</p>

                <div className="mt-auto">
                  <p><strong>Price:</strong> ₹{p.price}</p>
                  <p><strong>Available:</strong> {p.quantity}</p>

                  <button
                    className="btn w-100"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/products/${p.id}`);
                    }}
                    style={{
                      backgroundColor: "#008080",
                      color: "#fff",
                      border: "none",
                    }}
                  >
                    View Details
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}