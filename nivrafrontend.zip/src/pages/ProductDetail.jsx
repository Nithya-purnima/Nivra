import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../api/api";

export default function ProductDetail() {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);

  const { id } = useParams();
  const navigate = useNavigate();

  const userId = parseInt(localStorage.getItem("userId"));
  const userType = localStorage.getItem("userType");

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await api.get(`/products/${id}`);
        setProduct(res.data);
      } catch (err) {
        console.error("Error fetching product:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  const handleAddToWishlist = async () => {
    if (!userId) {
      alert("Please login first");
      navigate("/login/buyer");
      return;
    }

    try {
      await api.post(`/wishlist/add/${id}?userId=${userId}`);
      alert("Added to wishlist");
    } catch (err) {
      alert(err.response?.data || "Wishlist error");
    }
  };

  const handleAddToCart = async () => {
    if (!userId) {
      alert("Please login first");
      navigate("/login/buyer");
      return;
    }

    if (quantity <= 0) {
      alert("Invalid quantity");
      return;
    }

    try {
      await api.post(`/cart/add/${id}?userId=${userId}&quantity=${quantity}`);
      alert("Added to cart");
    } catch (err) {
      alert("Cart error");
    }
  };

  const handleRequest = async () => {
    if (!userId) {
      alert("Please login first");
      navigate("/login/buyer");
      return;
    }

    try {
      await api.post("/requests", {
        consumerId: userId,
        productId: id,
      });

      alert("Request sent!");

      if (window.confirm("Chat with seller?")) {
        navigate(`/chat/${userId}/${product.seller?.id}`);
      }
    } catch (err) {
      alert(err.response?.data || "Request failed");
    }
  };

  if (loading) return <div className="container mt-5">Loading...</div>;
  if (!product) return <div className="container mt-5">Not found</div>;

  return (
    <div className="container mt-5">
      <div className="row">
        {/* ✅ IMAGE FIX */}
        <div className="col-md-6">
          <img
            src={
              product.image
                ? `http://localhost:8080/api/products/image/${product.image}`
                : "https://via.placeholder.com/400"
            }
            alt={product.name}
            className="img-fluid rounded"
          />
        </div>

        <div className="col-md-6">
          {/* ✅ FIELD FIX */}
          <h2>{product.name}</h2>
          <p>{product.description}</p>
          <h4>₹{product.price}</h4>
          <p>Available: {product.quantity}</p>

          <input
            type="number"
            min="1"
            max={product.quantity}
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
            className="form-control mb-3"
            style={{ width: "120px" }}
          />

          {userType === "consumer" && (
            <>
              <button className="btn btn-outline-primary w-100 mb-2" onClick={handleAddToWishlist}>
                Wishlist
              </button>

              <button className="btn btn-primary w-100 mb-2" onClick={handleAddToCart}>
                Add to Cart
              </button>

              <button className="btn btn-success w-100 mb-2" onClick={handleRequest}>
                Request Product
              </button>

              {product.seller && (
                <button
                  className="btn btn-secondary w-100"
                  onClick={() => navigate(`/chat/${userId}/${product.seller.id}`)}
                >
                  Chat with Seller
                </button>
              )}
            </>
          )}

          {!userType && (
            <button className="btn btn-primary" onClick={() => navigate("/login/buyer")}>
              Login to Purchase
            </button>
          )}
        </div>
      </div>
    </div>
  );
}